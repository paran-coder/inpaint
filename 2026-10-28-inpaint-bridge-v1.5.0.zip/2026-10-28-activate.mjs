import http from 'node:http';import {spawn} from 'node:child_process';import {fileURLToPath} from 'node:url';import path from 'node:path';import {appendFile} from 'node:fs/promises';
const root=path.dirname(fileURLToPath(import.meta.url));
export function parseClient(value){if(!/^[a-f0-9]{32}$/.test(value||''))throw Error('Invalid connection code');return value;}
function local(method,route,body){return new Promise((resolve,reject)=>{const request=http.request({hostname:'127.0.0.1',port:4182,path:route,method,headers:{'Content-Type':'application/json','X-Inpaint-Launcher':'1'},timeout:1200},response=>{let data='';response.on('data',c=>{data+=c;if(data.length>8192)request.destroy();});response.on('end',()=>{try{if(response.statusCode!==200)throw Error('Bridge refused activation');resolve(JSON.parse(data));}catch(e){reject(e);}});});request.on('timeout',()=>request.destroy(Error('Bridge timeout')));request.on('error',reject);request.end(body?JSON.stringify(body):undefined);});}
export async function activate(client){parseClient(client);let running=false;
  try{const identity=await local('GET','/bridge/identity');if(identity.protocol!=='inpaint-bridge')throw Error('Port belongs to another application');running=true;}catch(error){if(!['ECONNREFUSED','ECONNRESET'].includes(error.code))throw error;}
  if(!running){const child=spawn(process.execPath,[path.join(root,'2026-10-28-bridge.mjs')],{cwd:root,detached:true,windowsHide:true,stdio:'ignore'});child.on('error',()=>{});child.unref();}
  for(let i=0;i<30;i++){try{const result=await local('POST','/bridge/launch',{client});if(result.protocol!=='inpaint-bridge')throw Error('Unexpected bridge');return;}catch{await new Promise(r=>setTimeout(r,250));}}
  throw Error('Bridge did not start');
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){try{await activate(process.argv[2]);}catch{await appendFile(path.join(root,'2026-10-28-bridge-errors.log'),new Date().toISOString()+' AI connection failed. Check Node, port 4182 and installation.\n');process.exitCode=1;}}
