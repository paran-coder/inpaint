using System;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;
class InpaintProtocol {
  [STAThread] static int Main(string[] args) {
    if(args.Length!=1)return 2;
    var match=Regex.Match(args[0],@"\Ainpaint-ai://connect/?\?client=([a-f0-9]{32})\z",RegexOptions.CultureInvariant);
    if(!match.Success)return 2;
    try {
      var root=AppDomain.CurrentDomain.BaseDirectory;
      var node=File.ReadAllText(Path.Combine(root,"2026-10-28-node-path.txt")).Trim();
      var script=Path.Combine(root,"2026-10-28-activate.mjs");
      if(!File.Exists(node)||!File.Exists(script)||node.Contains("\"")||script.Contains("\""))throw new Exception();
      var start=new ProcessStartInfo(node,"\""+script+"\" "+match.Groups[1].Value);
      start.WorkingDirectory=root;start.UseShellExecute=false;start.CreateNoWindow=true;start.WindowStyle=ProcessWindowStyle.Hidden;
      Process.Start(start);return 0;
    } catch {MessageBox.Show("AI 연결 파일을 찾을 수 없습니다. 브릿지를 다시 등록해주세요.","Inpaint Studio");return 1;}
  }
}
