@echo off
chcp 65001 >nul
node "%~dp02026-10-28-install.mjs" uninstall
pause
