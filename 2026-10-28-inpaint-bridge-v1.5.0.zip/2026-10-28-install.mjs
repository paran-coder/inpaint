import {execFileSync} from 'node:child_process';import {existsSync,writeFileSync,readFileSync} from 'node:fs';import {fileURLToPath} from 'node:url';import path from 'node:path';
const root=path.dirname(fileURLToPath(import.meta.url)),key='HKCU\\Software\\Classes\\inpaint-ai',exe=path.join(root,'2026-10-28-inpaint-connect.exe'),command='"'+exe+'" "%1"';
function registryValue(){try{return execFileSync('powershell.exe',['-NoLogo','-NoProfile','-NonInteractive','-Command',"[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding; (Get-Item -LiteralPath 'Registry::HKEY_CURRENT_USER\\Software\\Classes\\inpaint-ai\\shell\\open\\command' -ErrorAction Stop).GetValue('')"],{encoding:'utf8',windowsHide:true,stdio:['ignore','pipe','pipe']}).trim();}catch{return null;}}
function addRegistry(args){execFileSync('reg.exe',['add',...args],{windowsHide:true,stdio:'pipe'});}
function build(){if(process.platform!=='win32')throw Error('Windows 전용 설치 파일입니다.');if(existsSync(exe))return;const compiler=path.join(process.env.WINDIR||'C:\\Windows','Microsoft.NET','Framework64','v4.0.30319','csc.exe');if(!existsSync(compiler))throw Error('.NET Framework C# compiler가 필요합니다.');execFileSync(compiler,['/nologo','/target:winexe','/reference:System.Windows.Forms.dll','/out:'+exe,path.join(root,'2026-10-28-protocol-launcher.cs')],{windowsHide:true,stdio:'pipe'});}
const mode=process.argv[2]||'install';
try{
  if(mode==='--dry-run'){console.log(JSON.stringify({version:'1.5.0',registryKey:key,command,modifiesRegistry:false}));}
  else if(mode==='--build'){build();console.log('Launcher compiled; registry unchanged.');}
  else if(mode==='uninstall'){
    const current=registryValue();if(current===null){console.log('등록된 브릿지가 없습니다.');}else{if(current!==command)throw Error('다른 폴더의 등록이므로 삭제하지 않았습니다. 해당 설치 폴더에서 제거하세요.');execFileSync('reg.exe',['delete',key,'/f'],{windowsHide:true,stdio:'pipe'});console.log('AI 연결 등록만 제거했습니다. 파일·Codex·계정 설정은 유지됩니다.');}
  }else if(mode==='install'){
    const current=registryValue();if(current&&current!==command)throw Error('기존 등록을 덮어쓰지 않습니다. 이전 설치 폴더의 제거 파일을 먼저 실행하세요.');
    // A partial or third-party key is not overwritten.
    if(!current){try{execFileSync('reg.exe',['query',key],{stdio:'pipe',windowsHide:true});throw Error('이미 존재하는 등록입니다. 확인 후 수동으로 정리해주세요.');}catch(error){if(!error.status)throw error;}}
    build();writeFileSync(path.join(root,'2026-10-28-node-path.txt'),process.execPath+'\n');
    if(!current){addRegistry([key,'/ve','/t','REG_SZ','/d','URL:Inpaint AI Connection']);addRegistry([key,'/v','URL Protocol','/t','REG_SZ','/d','']);addRegistry([key+'\\shell\\open\\command','/ve','/t','REG_SZ','/d',command]);}
    console.log('AI 연결 등록 완료. https://inpaint-iota.vercel.app/ 에서 AI 연결을 누르세요. 상시 서비스는 설치하지 않았습니다.');
  }else throw Error('Unknown installation command');
}catch(error){console.error(error.message||'설치하지 못했습니다.');process.exitCode=1;}
