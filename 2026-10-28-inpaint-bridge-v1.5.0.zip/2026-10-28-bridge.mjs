import http from 'node:http';
import {createHash,randomBytes,timingSafeEqual} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {createApp} from './2026-10-28-server.mjs';

export const SITE='https://inpaint-iota.vercel.app/';
const GUID='258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const safeEqual=(a,b)=>typeof a==='string'&&typeof b==='string'&&Buffer.byteLength(a)===Buffer.byteLength(b)&&timingSafeEqual(Buffer.from(a),Buffer.from(b));
export class LeaseLifetime {
  constructor({onIdle,idleMs=30000,startupMs=120000,setTimer=setTimeout,clearTimer=clearTimeout}){Object.assign(this,{onIdle,idleMs,startupMs,setTimer,clearTimer});this.connections=new Set();this.timer=null;this.disposed=false;}
  arm(ms){if(this.disposed)return;this.clearTimer(this.timer);this.timer=this.setTimer(()=>{this.timer=null;if(!this.connections.size&&!this.disposed)this.onIdle();},ms);}
  start(){this.arm(this.startupMs);}
  attach(){if(this.disposed)throw Error('Bridge stopped');const id=Symbol();this.connections.add(id);this.clearTimer(this.timer);this.timer=null;let done=false;return()=>{if(done)return;done=true;this.connections.delete(id);if(!this.connections.size)this.arm(this.idleMs);};}
  dispose(){this.disposed=true;this.clearTimer(this.timer);this.connections.clear();}
}
function controlFrame(opcode,payload=Buffer.alloc(0)){return Buffer.concat([Buffer.from([0x80|opcode,payload.length]),payload]);}
export async function createBridge({siteURL=SITE,port=4182,idleMs=30000,startupMs=120000,codexAdapter,onStopped=()=>{}}={}){
  const site=new URL(siteURL);if(site.username||site.password||!(site.protocol==='https:'||(site.protocol==='http:'&&site.hostname==='127.0.0.1')))throw Error('허용할 사이트 주소가 올바르지 않습니다.');
  const origin=site.origin,pairs=new Map(),websockets=new Map(),requests=new Map();let closing=false,closePromise;
  const internal=createApp({provider:'codex',...(codexAdapter?{codexAdapter}:{})});
  await new Promise((resolve,reject)=>{internal.once('error',reject);internal.listen(0,'127.0.0.1',resolve);});
  const internalPort=internal.address().port;
  const lifetime=new LeaseLifetime({idleMs,startupMs,onIdle:()=>{void close();}});
  const server=http.createServer((req,res)=>{
    res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');
    const json=(code,data)=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(data));};
    const host=req.headers.host||'';if(!/^(127\.0\.0\.1|localhost):\d+$/.test(host))return json(403,{error:'로컬 주소가 필요합니다.'});
    let url;try{url=new URL(req.url,'http://'+host);}catch{return json(400,{error:'잘못된 요청입니다.'});}
    const localLauncher=!req.headers.origin&&!req.headers['sec-fetch-site']&&req.headers['x-inpaint-launcher']==='1';
    if(url.pathname==='/bridge/identity'&&!req.headers.origin&&req.method==='GET')return json(200,{protocol:'inpaint-bridge',version:'1.5.0'});
    if(url.pathname==='/bridge/launch'&&req.method==='POST'){
      if(!localLauncher)return json(403,{error:'로컬 실행기만 연결할 수 있습니다.'});
      let body='',bytes=0;req.on('data',chunk=>{bytes+=chunk.length;if(bytes>1024){req.destroy();return;}body+=chunk;});req.on('end',()=>{try{
        const client=body?JSON.parse(body).client:randomBytes(16).toString('hex');if(!/^[a-f0-9]{32}$/.test(client))return json(400,{error:'클라이언트 코드가 잘못되었습니다.'});
        const now=Date.now();for(const [id,p] of pairs)if(now-p.created>60000&&![...websockets.values()].some(ws=>ws.client===id))pairs.delete(id);
        let pair=pairs.get(client);if(pair)pair.created=now;if(!pair){if(pairs.size>=64)return json(429,{error:'연결 수가 너무 많습니다. 다른 탭의 연결을 해제하세요.'});pair={client,token:randomBytes(32).toString('base64url'),created:Date.now(),used:false};pairs.set(client,pair);}
        if(!websockets.size)lifetime.start();
        const launched=new URL(site);launched.hash=new URLSearchParams({bridge_token:pair.token,bridge_port:String(server.address().port)}).toString();
        return json(200,{protocol:'inpaint-bridge',version:'1.5.0',client,url:launched.href});
      }catch{return json(400,{error:'시작 요청을 읽지 못했습니다.'});}});return;
    }
    if(req.headers.origin!==origin)return json(403,{error:'허용된 편집기 사이트에서 연결해주세요.'});
    res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');
    if(req.method==='OPTIONS'){
      const requested=(req.headers['access-control-request-headers']||'').toLowerCase().split(',').map(s=>s.trim()).filter(Boolean);
      if(requested.some(s=>!['authorization','content-type','x-inpaint-tab'].includes(s)))return json(403,{error:'허용되지 않은 헤더입니다.'});
      res.setHeader('Access-Control-Allow-Methods','GET, POST, OPTIONS');res.setHeader('Access-Control-Allow-Headers','Authorization, Content-Type, X-Inpaint-Tab');res.setHeader('Access-Control-Allow-Private-Network','true');res.writeHead(204);res.end();return;
    }
    if(url.pathname==='/bridge/pair'&&req.method==='GET'){
      const pair=pairs.get(url.searchParams.get('client'));if(!pair||(!pair.used&&Date.now()-pair.created>60000))return json(404,{error:'AI 연결 버튼으로 브릿지를 시작해주세요.'});
      pair.used=true;return json(200,{token:pair.token,port:server.address().port});
    }
    const token=(req.headers.authorization||'').replace(/^Bearer /,'');const pair=[...pairs.values()].find(p=>safeEqual(p.token,token));
    if(!pair)return json(401,{error:'AI 연결이 필요합니다.'});
    const page=req.headers['x-inpaint-tab'];if(!/^[a-f0-9]{32}$/.test(page||''))return json(400,{error:'탭 연결 코드가 필요합니다.'});
    if(url.pathname==='/bridge/ping'&&req.method==='GET')return json(200,{version:'1.5.0',connected:true});
    if(url.pathname==='/bridge/disconnect'&&req.method==='POST'){
      for(const [socket,info] of websockets)if(info.client===pair.client&&info.page===page){info.detach();websockets.delete(socket);socket.destroy();}
      for(const [request,owner] of requests)if(owner.client===pair.client&&owner.page===page)request.destroy();
      if(![...websockets.values()].some(ws=>ws.client===pair.client))pairs.delete(pair.client);
      json(200,{disconnected:true});if(!websockets.size)lifetime.arm(50);return;
    }
    const allowed=(req.method==='GET'&&['/api/status','/api/progress'].includes(url.pathname))||(req.method==='POST'&&['/api/image','/api/cancel'].includes(url.pathname));
    if(!allowed)return json(404,{error:'제공하지 않는 경로입니다.'});
    if(![...websockets.values()].some(s=>s.client===pair.client&&s.page===page))return json(409,{error:'편집기 연결을 다시 확인해주세요.'});
    const upstream=http.request({hostname:'127.0.0.1',port:internalPort,path:url.pathname+url.search,method:req.method,headers:{'Content-Type':req.headers['content-type']||'application/json',Origin:`http://127.0.0.1:${internalPort}`}},response=>{
      if(res.destroyed){response.destroy();return;}res.writeHead(response.statusCode,{'Content-Type':response.headers['content-type']||'application/json'});response.pipe(res);
    });
    requests.set(upstream,{client:pair.client,page});upstream.on('error',()=>{if(!res.headersSent&&!res.destroyed)json(502,{error:'로컬 AI 요청이 종료되었습니다.'});else res.destroy();});upstream.on('close',()=>requests.delete(upstream));res.on('close',()=>upstream.destroy());req.on('aborted',()=>upstream.destroy());req.pipe(upstream);
  });
  server.on('upgrade',(req,socket,head)=>{
    const reject=()=>{socket.end('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n');};
    if(closing||req.url!=='/bridge/lease'||req.headers.origin!==origin||!/^127\.0\.0\.1:\d+$/.test(req.headers.host||'')||req.headers.upgrade?.toLowerCase()!=='websocket'||req.headers['sec-websocket-version']!=='13')return reject();
    const protocols=(req.headers['sec-websocket-protocol']||'').split(',').map(s=>s.trim()),token=protocols.find(s=>s.startsWith('auth.'))?.slice(5),pair=[...pairs.values()].find(p=>safeEqual(p.token,token));
    const page=protocols.find(p=>p.startsWith('page.'))?.slice(5);const key=req.headers['sec-websocket-key'];if(!/^[a-f0-9]{32}$/.test(page||'')||!pair||!protocols.includes('inpaint.v1')||!key||Buffer.from(key,'base64').length!==16)return reject();
    socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+createHash('sha1').update(key+GUID).digest('base64')+'\r\nSec-WebSocket-Protocol: inpaint.v1\r\n\r\n');
    pair.used=true;const info={client:pair.client,page,alive:true,detach:lifetime.attach()};websockets.set(socket,info);
    socket.on('error',()=>socket.destroy());socket.on('close',()=>{websockets.delete(socket);info.detach();});
    let buffer=Buffer.alloc(0);const consume=chunk=>{buffer=Buffer.concat([buffer,chunk]);if(buffer.length>1024)return socket.destroy();while(buffer.length>=2){const opcode=buffer[0]&15,len=buffer[1]&127;if((buffer[0]&0xf0)!==0x80||!(buffer[1]&128)||len>125||![8,9,10].includes(opcode))return socket.destroy();if(buffer.length<6+len)return;const key=buffer.subarray(2,6),data=Buffer.from(buffer.subarray(6,6+len));for(let i=0;i<len;i++)data[i]^=key[i%4];buffer=buffer.subarray(6+len);if(opcode===8){socket.end(controlFrame(8));return;}if(opcode===9)socket.write(controlFrame(10,data));if(opcode===10)info.alive=true;}};
    socket.on('data',consume);if(head.length)consume(head);
  });
  const pingTimer=setInterval(()=>{for(const [socket,info] of websockets){if(!info.alive){socket.destroy();continue;}info.alive=false;socket.write(controlFrame(9));}},10000);pingTimer.unref();
  async function close(){if(closePromise)return closePromise;closing=true;lifetime.dispose();clearInterval(pingTimer);closePromise=(async()=>{for(const socket of websockets.keys())socket.destroy();websockets.clear();for(const request of requests.keys())request.destroy();internal.closeAllConnections();server.closeAllConnections();await Promise.all([new Promise(r=>internal.close(r)),new Promise(r=>server.listening?server.close(r):r())]);pairs.clear();onStopped();})();return closePromise;}
  return {server,get port(){return server.address()?.port;},async listen(){try{await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});lifetime.start();}catch(error){await close();throw error;}},close};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const bridge=await createBridge();try{await bridge.listen();}catch{process.exitCode=1;}
  process.on('SIGTERM',()=>void bridge.close());process.on('SIGINT',()=>void bridge.close());
}
